<?php
session_start();
echo '<html><head><title>switch 配置</title></head><body>';
//echo 'hello world!';
//include_once("../lils/he.php");
include_once("cdrFiles.php");
echo '</body></html>';
?>
