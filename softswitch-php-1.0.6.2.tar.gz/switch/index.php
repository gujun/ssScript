<?php
header("Location: cfg");
?>
