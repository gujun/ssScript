<?php
require_once "remove_user.php";

remove_user("1906");
?>
