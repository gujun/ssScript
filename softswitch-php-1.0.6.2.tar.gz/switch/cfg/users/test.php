<?php
require_once "add_user.php";
//$varis = array();
//$varis["effective_caller_id_name"]= "1902";
add_user("1906",'$${default_password}',NULL,"newgroup3");
?>
