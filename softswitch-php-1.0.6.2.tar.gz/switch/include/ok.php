<?php
echo "<html>";
echo "<head>";
echo "<title>提示</title>";
echo "</head>";
echo "<body onload=\"alert('操作成功！');\">";
echo "<h1>操作成功！</h1>";
echo "</body>";
echo "</html>";
?>          
