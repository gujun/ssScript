<?php
$switchroot = '/home/pub/release/fs106/';
?>
