<?php
echo "<html>";
echo "<head>";
echo "<title>错误</title>";
echo "</head>";
echo "<body onload=\"alert('操作不成功，文件已经删除！');\">";
echo "<h1>操作不成功，文件已经删除！</h1>";
echo "</body>";
echo "</html>";
?>          
